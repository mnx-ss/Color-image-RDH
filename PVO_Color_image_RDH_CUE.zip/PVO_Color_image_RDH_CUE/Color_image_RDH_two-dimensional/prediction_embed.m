function [R,G,B,nBit]=prediction_embed(R,G,B,NL,BPOS,Id,a,b,Num,CR) %I,I,I,NL,BPOS,Id,a,b,Num
%��άӳ��
CDH=cell(4,1);
CDH{1,1}=[1 2 3 ];
CDH{2,1}=[2 4];
CDH{3,1}=[3 4];
CDH{4,1}=[1 4];
% CDH{5,1}=[2 3 4 6 7];
% CDH{6,1}=[5 6 7 8];
% CDH{7,1}=[6 8];
% CDH{8,1}=[8];
% ST=floor((a*b-1)/3);%��Ԫ����Ŀ
% L=a*b-1;
P_Num=length(NL);
% Iw=Uc;
% [Val,Id]=sort(RCp,'ascend');
% New_Bpoint=Bpoint(Id,:);
% Num=numel(RCp);
New_Bpoint=BPOS;
% Mse=round(rand(1,CR));
RP=(0:a-1);CP=(0:b-1);RR=ones(1,b);CC=ones(a,1);
nBit=0;
for i=1:P_Num-1
%     i
    N=floor(Id(i)/Num);
    if N==0
            Uc=R;
            Rc=G;
            Iw=R;
    elseif N== 1
            Uc=G;
            Rc=B;
            Iw=G;
    elseif N== 2
            Uc=B;
            Rc=G;
            Iw=B;
    end
%     Peak=0;
    r=New_Bpoint(i,1);c=New_Bpoint(i,2);
    Pixel_B=Uc(r:r+a-1,c:c+b-1)';
    Pixel_B(Pixel_B==255)=254;
    Pixel_B(Pixel_B==0)=1;
    Pixel_RB=Rc(r:r+a-1,c:c+b-1)';
    y=Pixel_RB(:);
    x=Pixel_B(:);
    TLine=(RP+r)'*RR;TRow=CC*(CP+c);%��λ�ö�Ӧ��
    TLine=TLine'; TRow=TRow';%��λ�ö�Ӧ��
    posplx=[TLine(:) TRow(:)];% need vrify
%     [Id]=SD_meoth(y,k); %SD�����޳���Ⱥ��
%      [Id]=MAD_meoth(y,k);%MAD ������Ҫ����kֵ
%     if isempty(Id)
%         continue;
%     end
%     y=y(Id);
%     x=x(Id);%(ID)
%     posplx=posplx(Id,:);%(ID,:)
    [Val,ID]=sort(y,'descend');%
    pix=x(ID);%(ID)
    posd=posplx(ID,:);%(ID,:)
    [Y,In]=sort(pix,'ascend');%'descend'
%     posd=PosA(In,:);
    PR=ones(length(Y),1)*Y(end);%1
   Tn=sign(ones(length(Y),1)*In(end)-In);%û�д� 1
   PE=(Y-PR).*Tn;%��0
   [Vaule,Inn]=sort(In,'ascend');
   RPE=PE(Inn);
   RPE(In(end))=[];
   posd(In(end),:)=[];
%    ex=RPE;
   [IDD]=find(-2<RPE & RPE<3);
   TN=length(IDD);
   if TN>1
       ST=floor(TN/2);
       IDD=IDD(1:ST*2,1);
       RPE1=RPE(IDD,1);
       posd1=posd(IDD,:);
       [TIw,Nbit]=ThreeEmbedding_data(Iw,CDH,RPE1,ST,posd1,-1);
       Iw=TIw;
       nBit=nBit+Nbit;
        RPE(IDD)=[];
        posd(IDD,:)=[];
   end
%    ex=PE(1:end-1,:);
%    Peak=Peak+length(find(ex<2 & ex >-1));
   %posd=posd(1:end-1,:);
   
    P=[1,0];%��ֵǶ���
    for j=1:length(RPE)
       if (~isempty(find(P==RPE(j))))
            nBit=nBit+1;
            Iw(posd(j,1),posd(j,2))=Iw(posd(j,1),posd(j,2))-round(rand(1));
%             Spix(In(j))=Spix(In(j))-Mse(nBit);
       else
           Iw(posd(j,1),posd(j,2))=Iw(posd(j,1),posd(j,2))-1;
%             Spix(In(j))=Spix(In(j))-1;
        end
        if nBit >= CR
            break;
        end
        
   end
    if nBit >= CR
        break;
    end
    %�ҳ����Ƕ���ʵ�λ�� �ڶ���Ƕ��
%    [Val,IID]=sort(y,'ascend');%ascend
%     Spix=Spix(ID);%(ID)
    posa=posplx(ID,:);
    Pixel_B=Iw(r:r+a-1,c:c+b-1)';
    x2=Pixel_B(:);
    Spix=x2(ID);
%     posA=Pos;%(ID,:)(IID,:)
   [OY,In]=sort(Spix,'ascend');
%    posA=posA(In,:);
   PR=ones(length(OY),1)*OY(1);
   Tn=sign(ones(length(OY),1)*In(1)-In);%û�д�
   PE=(OY-PR).*Tn;%��0
  [Vaule,Inn]=sort(In,'ascend');
   RPE=PE(Inn);
   RPE(In(1))=[];
   posa(In(1),:)=[];
%    ex=RPE;
    [IDD]=find(-2<RPE & RPE<3);
   TN=length(IDD);
   if TN>1
       ST=floor(TN/2);
       IDD=IDD(1:ST*2,1);
       RPE2=RPE(IDD,1);
       posd2=posa(IDD,:);
       [TIw2,Nbit]=ThreeEmbedding_data(Iw,CDH,RPE2,ST,posd2,1);
       Iw=TIw2;
       nBit=nBit+Nbit;
        RPE(IDD)=[];
        posa(IDD,:)=[];
   end
   
%     Peak=Peak+length(find(ex<2 & ex >-1));
%     R(i)=Peak/9;
   for j=1:length(RPE)
       if (~isempty(find(P==RPE(j))))
            nBit=nBit+1;      
            Iw(posa(j,1),posa(j,2))=Iw(posa(j,1),posa(j,2))+round(rand(1));
       else
            Iw(posa(j,1),posa(j,2))=Iw(posa(j,1),posa(j,2))+1;
        end
        if nBit >= CR
            break;
        end
   end
%      switch N
%         case 0
%             R=Iw;
%         case 1
%             G=Iw;
%         case 2
%             B=Iw;
%      end
           if N==0
                     R=Iw;
            elseif N== 1
                    G=Iw;
            elseif N== 2
                    B=Iw;
           end
   
    if nBit >= CR
            break;
    end
end
end

function [I,Nbit]=ThreeEmbedding_data(I,bset_CDHn,PE,ST,R_pos,bit)
PE=abs(PE-0.5);
% L=length(Thre_PE(:,1));
Nbit=0;
for i=1:ST
    Thre_PE=PE((i-1)*2+1:i*2,1)';
%     Id=0;
    if isequal(Thre_PE,[0.5 0.5])
        Id=1;
    elseif isequal(Thre_PE,[1.5 0.5])
        Id=2;
    elseif isequal(Thre_PE,[0.5 1.5])
        Id=3;
    elseif isequal(Thre_PE,[1.5 1.5])
       Id=4;
%     elseif isequal(Thre_PE,[0.5 0.5 1.5])
%         Id=5;
%     elseif isequal(Thre_PE,[1.5 0.5 1.5])
%        Id=6;
%     elseif isequal(Thre_PE,[0.5 1.5 1.5])
%         Id=7;
%     elseif isequal(Thre_PE,[1.5 1.5 1.5])
%        Id=8; 
    end
%     if Id==0
%         K=2;
%     else
    DR=bset_CDHn{Id,1};
    Nbit=Nbit+log2(length(DR));
    ID=randperm(length(DR),1);
    K=DR(ID);
%     end
     P=(i-1)*2;
    switch K
        case 1
            continue
        case 2
            I(R_pos(P+1,1),R_pos(P+1,2))=I(R_pos(P+1,1),R_pos(P+1,2))+bit;
        case 3
            I(R_pos(P+2,1),R_pos(P+2,2))=I(R_pos(P+2,1),R_pos(P+2,2))+bit;
        case 4
            I(R_pos(P+1,1),R_pos(P+1,2))=I(R_pos(P+1,1),R_pos(P+1,2))+bit;
            I(R_pos(P+2,1),R_pos(P+2,2))=I(R_pos(P+2,1),R_pos(P+2,2))+bit;
   end
%     if (Nbit>Payload | Nbit==Payload)
%     break
%     end
end
% Iw(:,:,1)=I;
% Iw(:,:,2)=I;
% Iw(:,:,3)=I;

end

function  [ID]=SD_meoth(y,k)
MeaV=mean(y);
StrV=std(y);
MaxV=MeaV+k*StrV;
MinV=MeaV-k*StrV;
ID=find(y>MinV & y<MaxV);
end

function  [ID]=MAD_meoth(y,k)
MedV=median(y);
YMed1=abs(MedV*ones(length(y),1)-y);
Dit=YMed1./median(YMed1);
ID=find(Dit<k);
end
