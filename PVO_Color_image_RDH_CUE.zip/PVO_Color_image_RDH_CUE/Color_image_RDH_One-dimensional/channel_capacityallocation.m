function [CR, CG, CB, MRCp, MGCp, MBCp, Bpoint] = channel_capacityallocation(I,a,b,set,s,Capty)

IR=I(:,:,1);
IG=I(:,:,2);
IB=I(:,:,3);
[A,B]=size(IR);
NA=floor((A-2)/a);NB=floor((B-2)/b);
LL=a*b-1;
num=ceil((NA*NB)*LL/2);
RNerr=zeros(num,1);
GNerr=zeros(num,1);
BNerr=zeros(num,1);
RCp=zeros(num,1);
GCp=zeros(num,1);
BCp=zeros(num,1);
N=0;EN=0;SEN=0;
RP=(0:a-1);CP=(0:b-1);RR=ones(1,b);CC=ones(a,1);
Bpoint=zeros(ceil((NA*NB)/2),2);
for i0 = 1:NA
    
    for j0 = 1:NB
            BN=i0+j0;
       if mod(BN,2)==set
           i=(i0-1)*a+2;j=(j0-1)*b+2;
%            Line=(RP+i)';Row=(CP+j)';%ȡ������λ��  
         N=N+1;
         Bpoint(N,:)=[i,j];
%          up=I(i-1,j:b+j-1);down=I(i+a,j:b+j-1);
%          Left=I(i:a+i-1,j-1);Right=I(i:a+i-1,j+b);
%R channel
        I=IR;
        up=I(i-1,j:b+j-1);down=I(i+a,j:b+j-1);
        Left=I(i:a+i-1,j-1);Right=I(i:a+i-1,j+b);
        sup=[up(2:end) up(end)]; sdown=[down(2:end) down(end)];
        sLeft=[Left(2:end);Left(end)]; sRight=[Right(2:end) ;Right(end)];
%         NL=sum((up-sup).^2)+sum((down-sdown).^2)+sum((Left-sLeft).^2)+sum((Right-sRight).^2)+sum((up-down).^2)+sum((Left-Right).^2)+...
%                +(up(end)-Right(1))^2+(Right(end)-down(end))^2+(down(1)-Left(end))^2+(Left(1)-up(1))^2;
        NL=sum(abs(up-sup))+sum(abs(down-sdown))+sum(abs(Left-sLeft))+sum(abs(Right-sRight))+sum(abs(up-down))+sum(abs(Left-Right))+...
               +abs(up(end)-Right(1))+abs(Right(end)-down(end))+abs(down(1)-Left(end))+abs(Left(1)-up(1));
        RCp(N,1)= NL;
        
%G channel
       I=IG;
        up=I(i-1,j:b+j-1);down=I(i+a,j:b+j-1);
        Left=I(i:a+i-1,j-1);Right=I(i:a+i-1,j+b);
        sup=[up(2:end) up(end)]; sdown=[down(2:end) down(end)];
        sLeft=[Left(2:end);Left(end)]; sRight=[Right(2:end) ;Right(end)];
%         NL=sum((up-sup).^2)+sum((down-sdown).^2)+sum((Left-sLeft).^2)+sum((Right-sRight).^2)+sum((up-down).^2)+sum((Left-Right).^2)+...
%                +(up(end)-Right(1))^2+(Right(end)-down(end))^2+(down(1)-Left(end))^2+(Left(1)-up(1))^2;
        NL=sum(abs(up-sup))+sum(abs(down-sdown))+sum(abs(Left-sLeft))+sum(abs(Right-sRight))+sum(abs(up-down))+sum(abs(Left-Right))+...
               +abs(up(end)-Right(1))+abs(Right(end)-down(end))+abs(down(1)-Left(end))+abs(Left(1)-up(1));
        GCp(N,1)= NL;
 %B channel
       I=IB;
        up=I(i-1,j:b+j-1);down=I(i+a,j:b+j-1);
        Left=I(i:a+i-1,j-1);Right=I(i:a+i-1,j+b);
        sup=[up(2:end) up(end)]; sdown=[down(2:end) down(end)];
        sLeft=[Left(2:end);Left(end)]; sRight=[Right(2:end) ;Right(end)];
%         NL=sum((up-sup).^2)+sum((down-sdown).^2)+sum((Left-sLeft).^2)+sum((Right-sRight).^2)+sum((up-down).^2)+sum((Left-Right).^2)+...
%                +(up(end)-Right(1))^2+(Right(end)-down(end))^2+(down(1)-Left(end))^2+(Left(1)-up(1))^2;
        NL=sum(abs(up-sup))+sum(abs(down-sdown))+sum(abs(Left-sLeft))+sum(abs(Right-sRight))+sum(abs(up-down))+sum(abs(Left-Right))+...
               +abs(up(end)-Right(1))+abs(Right(end)-down(end))+abs(down(1)-Left(end))+abs(Left(1)-up(1));
        BCp(N,1)= NL;
        
       else
       i=(i0-1)*a+2;j=(j0-1)*b+2;
       Line=(RP+i)';Row=(CP+j)';%ȡ������λ�� 
       %R channel
        I=IR;
       spilx=I(Line,Row)';%ȡ�����غ�λ��Ҫ��Ӧ
        pilx=spilx(:);
        [Y, In] = sort(pilx,s);
       PR=ones(length(Y),1)*Y(1);
       Tn=sign(In-ones(length(Y),1)*In(1));
       PE=(Y-PR).*Tn;%��0
       ex=PE(2:end,:);
       RNerr(EN+1:EN+LL) =ex;
       %G channel
       I=IG;
       spilx=I(Line,Row)';%ȡ�����غ�λ��Ҫ��Ӧ
        pilx=spilx(:);
        [Y, In] = sort(pilx,s);
       PR=ones(length(Y),1)*Y(1);
       Tn=sign(In-ones(length(Y),1)*In(1));
       PE=(Y-PR).*Tn;%��0
       ex=PE(2:end,:);
       GNerr(EN+1:EN+LL) =ex;
       %B channel
       I=IB;
       spilx=I(Line,Row)';%ȡ�����غ�λ��Ҫ��Ӧ
        pilx=spilx(:);
       [Y, In] = sort(pilx,s);
       PR=ones(length(Y),1)*Y(1);
       Tn=sign(In-ones(length(Y),1)*In(1));
       PE=(Y-PR).*Tn;%��0
       ex=PE(2:end,:);
       BNerr(EN+1:EN+LL) =ex;
       
       EN=EN+LL;
        end

    end
end
Bpoint= Bpoint(1:N,:);
MRCp= RCp(1:N,1);
MGCp= GCp(1:N,1);
MBCp= BCp(1:N,1);
% RCp= RCp(1:N,1);
% GCp= GCp(1:N,1);
% BCp= BCp(1:N,1);
% MRCp=RCp(1:N,1)*1+GCp(1:N,1)*0.5+BCp(1:N,1)*0.5;
% MGCp=GCp(1:N,1)*1+RCp(1:N,1)*0.5+BCp(1:N,1)*0.5;
% MBCp=BCp(1:N,1)*1+GCp(1:N,1)*0.5+RCp(1:N,1)*0.5;
RNerr=RNerr(1:EN,1);
GNerr=GNerr(1:EN,1);
BNerr=BNerr(1:EN,1);
NR=numel(find(RNerr>-1 & RNerr<2));
NG=numel(find(GNerr>-1 & GNerr<2));
NB=numel(find(BNerr>-1 & BNerr<2));
CR=round((NR/(NR+NG+NB))*Capty);
CG=round((NG/(NR+NG+NB))*Capty);
CB=Capty-CR-CG;
end
