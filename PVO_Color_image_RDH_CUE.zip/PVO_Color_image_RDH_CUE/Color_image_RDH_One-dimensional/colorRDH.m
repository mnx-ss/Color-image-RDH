% date: May 7th, 2016
% updated: July 21, 2016
% author: Heng YAO, hyao@usst.edu.cn
% pls cite the article as: H. Yao, C. Qin, Z. Tang, and Y. Tian, "Guided filtering based color image reversible data hiding," Journal of Visual Communication and Image Representation, vol. 43, pp. 152-163, 2017.

function [performance]=colorRDH(I,k)

% generate the double-layer embedding mask
% mask1: the first mask for embedding, 1 stands for reference pixels, 0 stands
% for to be estimated pixels
% mask2=1-mask1;
% purecapacity=length(puremessage);
mask1=zeros(size(I, 1), size(I, 2));
mask2=mask1;
rows1 = 1:2:size(I, 1);
rows2 = 2:2:size(I, 1);
cols1 = 1:2:size(I, 2);
cols2 = 2:2:size(I, 2);
mask1(rows1, cols1) = 1;
mask1(rows2, cols2) = 1;
mask2(rows1, cols2) = 1;
mask2(rows2, cols1) = 1;
Io=I;
% compressed location map of locationcodeX generation with the lengh of bitLLMX, 
% and newI is the modified image with 0-->1 and 255--->254 
% [newI,locationcodeR1,locationcodeG1,locationcodeB1,locationcodeR2,locationcodeG2, locationcodeB2,bitLLM]=creatlocationmap (I,mask1,mask2);

%partition the eachlayer 
layer1part = 0.5;

Rchannel=I(:,:,1);
Gchannel=I(:,:,2);
Bchannel=I(:,:,3);
LM = 0;
[bin_LM bin_LM_len R] = LocationMap(Rchannel);
LM = LM + bin_LM_len;
[bin_LM bin_LM_len G] = LocationMap(Gchannel);
LM = LM + bin_LM_len;
[bin_LM bin_LM_len B] = LocationMap(Bchannel);
LM = LM + bin_LM_len;
% I=newI;
% Rchannel(Rchannel==0)=1;
% Rchannel(Rchannel==255)=254;
% Gchannel(Gchannel==0)=1;
% Gchannel(Gchannel==255)=254;
% Bchannel(Bchannel==0)=1;
% Bchannel(Bchannel==255)=254;
% Rchannel=I(:,:,1);
% Gchannel=I(:,:,2);
% Bchannel=I(:,:,3);
performance = zeros(5,100);
n=1;
% firstlayer embedding
for purecapacity=[10000:10000:200000]
    k2=1; 
    perf=zeros(5,22);
    for a=2:5 %:5
        for b=2:5 %:5
capacity1=ceil(purecapacity*layer1part)+round(LM/2);%
capacity2=purecapacity-ceil(purecapacity*layer1part)+round(LM/2);%round(LM/2)/2
display('start 1st layer payload distribution...');
[CR, CG, CB, RCp, GCp, BCp, Bpoint] = channel_capacityallocation(I,a,b,0,'descend',capacity1); %  capacity allocation 
NL=[RCp;GCp;BCp];
BPOS=[Bpoint;Bpoint;Bpoint];
Num=length(RCp);
Id=(1:3*Num)';
[Y,In]=sort(NL,'ascend');%'descend'
BPOS=BPOS(In,:);
Id=Id(In);
% first layer, embeding message in R, total bits=capRed1+LSBbits(6bits,leftbinR1 and rightbinR1)
display('start 1st layer embedding in R1 pixels...');
[R,G,B,Bit1,BN2]=prediction_embed(Rchannel,Gchannel,Bchannel,NL,BPOS,Id,a,b,Num,capacity1);%embedding
    if Bit1< capacity1
        break;
    end
embedI=I;
embedI(:,:,1)=R;
embedI(:,:,2)=G;
embedI(:,:,3)=B;
% LM2 = 0;
% [bin_LM bin_LM_len Rw] = LocationMap_circle(R);
% LM2 = LM2+ bin_LM_len;
% [bin_LM bin_LM_len Gw] = LocationMap_circle(G);
% LM2 = LM2 + bin_LM_len;
% [bin_LM bin_LM_len Bw] = LocationMap_circle(B);
% LM2 = LM2 + bin_LM_len;
% capacity2=capacity2+LM2;
display('start 2st layer payload distribution...');
[CR, CG, CB, RCp, GCp, BCp, Bpoint] = channel_capacityallocation(embedI,a,b,1,'descend',capacity2); %  capacity allocation 
NL=[RCp;GCp;BCp];
BPOS=[Bpoint;Bpoint;Bpoint];
Num=length(RCp);
Id=(1:3*Num)';
[Y,In]=sort(NL,'ascend');%'descend'
BPOS=BPOS(In,:);
Id=Id(In);

display('start 1st layer embedding in R1 pixels...');
[RIw,GIw,BIw,Bit2,BN1]=prediction_embed(R,G,B,NL,BPOS,Id,a,b,Num,capacity2);%embedding
 if Bit2< capacity2
        break;
end

 
S_nBit=Bit1+Bit2;
BN=BN1+BN2;
Iw=I;
Iw(:,:,1)=RIw;
Iw(:,:,2)=GIw;
Iw(:,:,3)=BIw;
[psnr,mse]=imcpsnr(Iw,Io);
perf(:,k2) = [a;b; S_nBit;BN;psnr];
k2=k2+1;
        end
    end
    [va,id]=max(perf(end,:));
    performance(:,n)=perf(:,id);
    if va==0
        break;
    end
    n = n + 1;
end

end

function [cpsnr,mse] = imcpsnr(X, Y, peak, b)

if( nargin < 3 )
 peak = 255;
end

if( nargin < 4 )
 b = 0;
end

if( b > 0 )
 X = X(b:size(X,1)-b, b:size(X,2)-b,:);
 Y = Y(b:size(Y,1)-b, b:size(Y,2)-b,:);
end

dif = (X - Y);
dif = dif .* dif;
mse = sum( dif(:) ) / numel(dif) + 1e-32;
cpsnr = 10 * log10( peak*peak / mse );

end
        
function [newI,locationcodeR1,locationcodeG1,locationcodeB1,locationcodeR2,locationcodeG2, locationcodeB2,bitLLM ] = creatlocationmap (I,mask1,mask2)

I1=I(:,:,1);
I2=I(:,:,2);
I3=I(:,:,3);
newI=(I+1).*double(I==0)+(I-1).*double(I==255)+I.*double((I<255)&(I>0));

[locationcodeR1, bitLLMR1]=locationcoding(I1,mask2);

[locationcodeG1, bitLLMG1]=locationcoding(I2,mask2);

[locationcodeB1, bitLLMB1]=locationcoding(I3,mask2);

[locationcodeR2, bitLLMR2]=locationcoding(I1,mask1);

[locationcodeG2, bitLLMG2]=locationcoding(I2,mask1);

[locationcodeB2, bitLLMB2]=locationcoding(I3,mask1);

bitLLM=[bitLLMR1; bitLLMG1 ; bitLLMB1; bitLLMR2; bitLLMG2; bitLLMB2 ];


end

function [locationcode, bitLLM] = locationcoding (Img,mask2)
locationmap=double(Img==0|Img==255).*mask2+double(Img==1|Img==254).*mask2*2;
locationsequence=locationmap(find (locationmap~=0))';
lengthsequence=length(locationsequence);
if lengthsequence==0
    locationcode=0;
else if (sum(locationsequence)==0)|(sum(locationsequence)==lengthsequence)
    locationcode=0;  
else 
    locationcode = compresscoding(locationsequence);


    end
end
lengthlocation=length(locationcode); 
lengthLLM= ceil(log2(size(locationmap,1)*size(locationmap,2)));
bitLLM= decimal2binary (lengthlocation, lengthLLM);

end

function [Y] = clip(X, lo, hi)

Y = X;
Y(X<lo) = lo;
Y(X>hi) = hi;

end

function code =compresscoding (seq) 
% Check the incoming orientation and adjust if necessary 
[row_s, col_s] = size(seq); 
if (row_s > 1), 
    seq = seq.'; 
end 
counts = [1,1]; 
cum_counts = [0, cumsum(counts)]; 
total_count = cum_counts(end); 
N = 16; 
dec_low = 0; 
dec_up = 2^N-1; 
E3_count = 0; 
% Obtain an over estimate for the length of CODE and initialize CODE 
code_len = length(seq) * ( ceil(log2(length(counts))) + 2 ) + N; 
code = zeros(1, code_len); 
code_index = 1; 
 
% Loop for each symbol in SEQ 
for k = 1:length(seq) 
 
    symbol = seq(k); 
    % Compute the new lower bound 
    dec_low_new = dec_low + floor( (dec_up-dec_low+1)*cum_counts(symbol+1-1)/total_count ); 
 
    % Compute the new upper bound 
    dec_up = dec_low + floor( (dec_up-dec_low+1)*cum_counts(symbol+1)/total_count )-1; 
 
    % Update the lower bound 
    dec_low = dec_low_new; 
     
    % Check for E1, E2 or E3 conditions and keep looping as long as they occur. 
    while( isequal(bitget(dec_low, N), bitget(dec_up, N)) || ... 
        (isequal(bitget(dec_low, N-1), 1) && isequal(bitget(dec_up, N-1), 0) ) ), 
         
        % If it is an E1 or E2 condition, 
        if isequal(bitget(dec_low, N), bitget(dec_up, N)), 
 
            % Get the MSB 
            b = bitget(dec_low, N); 
            code(code_index) = b; 
            code_index = code_index + 1; 
         
            % Left shifts 
            dec_low = bitshift(dec_low, 1) + 0; 
            dec_up  = bitshift(dec_up, 1) + 1; 
             
            % Check if E3_count is non-zero and transmit appropriate bits 
            if (E3_count > 0), 
                % Have to transmit complement of b, E3_count times. 
                code(code_index:code_index+E3_count-1) = bitget(bitcmp(b,'uint8'),1).*ones(1, E3_count); 
                code_index = code_index + E3_count; 
                E3_count = 0; 
            end 
 
            % Reduce to N for next loop 
            dec_low = bitset(dec_low, N+1, 0); 
            dec_up  = bitset(dec_up, N+1, 0); 
             
        % Else if it is an E3 condition     
        elseif ( (isequal(bitget(dec_low, N-1), 1) && ... 
            isequal(bitget(dec_up, N-1), 0) ) ), 
             
            % Left shifts 
            dec_low = bitshift(dec_low, 1) + 0; 
            dec_up  = bitshift(dec_up, 1) + 1; 
 
            % Reduce to N for next loop 
            dec_low = bitset(dec_low, N+1, 0); 
            dec_up  = bitset(dec_up, N+1, 0); 
             
            % Complement the new MSB of dec_low and dec_up 
            dec_low = bitxor(dec_low, 2^(N-1) ); 
            dec_up  = bitxor(dec_up, 2^(N-1) ); 
             
            % Increment E3_count to keep track of number of times E3 condition is hit. 
            E3_count = E3_count+1; 
        end 
    end 
    counts(symbol) = counts(symbol)+1; 
    cum_counts = [0, cumsum(counts)]; 
 
    % Compute the Word Length required. 
    total_count = cum_counts(end); 
end 
  
% Terminate encoding 
bin_low = de2bi(dec_low, N, 'left-msb'); 
if E3_count==0 
    % Just transmit the final value of the lower bound bin_low        
    code(code_index:code_index + N - 1) = bin_low; 
    code_index = code_index + N; 
else 
   % Transmit the MSB of bin_low.  
   b = bin_low(1); 
   code(code_index) = b; 
   code_index = code_index + 1; 
    
   % Then transmit complement of b (MSB of bin_low), E3_count times.  
   
   code(code_index:code_index+E3_count-1) = bitget(bitcmp(b,'uint8'),1).*ones(1, E3_count); 
   code_index = code_index + E3_count; 
 
   % Then transmit the remaining bits of bin_low 
   code(code_index:code_index+N-2) = bin_low(2:N); 
   code_index = code_index + N - 1; 
end           
 
% Output only the filled values 
code = code(1:code_index-1); 
% Set the same output orientation as seq 
if (row_s > 1) 
    code = code.'; 
end 
end

function bitnumber= decimal2binary (decimalnumber, bitlength)
binarynumber=dec2bin(decimalnumber);
bitnumber = zeros(1, bitlength);
actualbitlength= floor(log2(decimalnumber))+1;
for i= 1:actualbitlength
    bitnumber (1,bitlength-i+1)=str2num(binarynumber(actualbitlength-i+1));
end

end



