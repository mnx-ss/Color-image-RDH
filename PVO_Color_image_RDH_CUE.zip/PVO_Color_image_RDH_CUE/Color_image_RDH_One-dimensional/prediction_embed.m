function [R,G,B,nBit,i]=prediction_embed(R,G,B,NL,BPOS,Id,a,b,Num,CR) %Rchannel,Gchannel,Bchannel,NL,BPOS,Id,a,b,Num

P_Num=length(NL);
% Iw=Uc;
% [Val,Id]=sort(RCp,'ascend');
% New_Bpoint=Bpoint(Id,:);
% Num=numel(RCp);
New_Bpoint=BPOS;
Mse=round(rand(1,CR));
RP=(0:a-1);CP=(0:b-1);RR=ones(1,b);CC=ones(a,1);
nBit=0;
for i=1:P_Num
    
    N=floor(Id(i)/Num);
    if N==0
            Uc=R;
            Rc=G;
            Iw=R;
    elseif N== 1
            Uc=G;
            Rc=B;
            Iw=G;
    elseif N== 2
            Uc=B;
            Rc=G;
            Iw=B;
    end
%     Peak=0;
    r=New_Bpoint(i,1);c=New_Bpoint(i,2);
    Pixel_B=Uc(r:r+a-1,c:c+b-1)';
    Pixel_B(Pixel_B==255)=254;
    Pixel_B(Pixel_B==0)=1;
    Pixel_RB=Rc(r:r+a-1,c:c+b-1)';
    y=Pixel_RB(:);
    x=Pixel_B(:);
    TLine=(RP+r)'*RR;TRow=CC*(CP+c);%��λ�ö�Ӧ��
    TLine=TLine'; TRow=TRow';%��λ�ö�Ӧ��
    posplx=[TLine(:) TRow(:)];% need vrify
%     [Id]=SD_meoth(y,k); %SD�����޳���Ⱥ��
%      [Id]=MAD_meoth(y,k);%MAD ������Ҫ����kֵ
%     if isempty(Id)
%         continue;
%     end
%     y=y(Id);
%     x=x(Id);%(ID)
%     posplx=posplx(Id,:);%(ID,:)
    [Val,ID]=sort(y,'descend');%
    pix=x(ID);%(ID)
    Pos=posplx(ID,:);%(ID,:)
    [Y,In]=sort(pix,'ascend');%'descend'
    posd=Pos(In,:);
    PR=ones(length(Y),1)*Y(end);%1
   Tn=sign(ones(length(Y),1)*In(end)-In);%û�д� 1
   PE=(Y-PR).*Tn;%��0
   ex=PE(1:end-1,:);
%    Peak=Peak+length(find(ex<2 & ex >-1));
   posd=posd(1:end-1,:);Spix=pix;
    L=length(pix);
    P=[1,0];%��ֵǶ���
    for j=1:L-1
       if (~isempty(find(P==ex(j))))
            nBit=nBit+1;
            Iw(posd(j,1),posd(j,2))=Iw(posd(j,1),posd(j,2))-Mse(nBit);
            Spix(In(j))=Spix(In(j))-Mse(nBit);
       else
           Iw(posd(j,1),posd(j,2))=Iw(posd(j,1),posd(j,2))-1;
            Spix(In(j))=Spix(In(j))-1;
        end
        if nBit >= CR
            break;
        end
        
   end
    if nBit >= CR
        break;
    end
    %�ҳ����Ƕ���ʵ�λ�� �ڶ���Ƕ��
%    [Val,IID]=sort(y,'ascend');%ascend
%     Spix=Spix(ID);%(ID)
    posA=Pos;%(ID,:)(IID,:)
   [OY,In]=sort(Spix,'ascend');
   posA=posA(In,:);
   PR=ones(length(OY),1)*OY(1);
   Tn=sign(ones(length(OY),1)*In(1)-In);%û�д�
   PE=(OY-PR).*Tn;%��0
   ex=PE(2:end,:);posa=posA(2:end,:);
%     Peak=Peak+length(find(ex<2 & ex >-1));
%     R(i)=Peak/9;
   for j=1:L-1
       if (~isempty(find(P==ex(j))))
            nBit=nBit+1;      
            Iw(posa(j,1),posa(j,2))=Iw(posa(j,1),posa(j,2))+Mse(nBit);
       else
            Iw(posa(j,1),posa(j,2))=Iw(posa(j,1),posa(j,2))+1;
        end
        if nBit >= CR
            break;
        end
   end
%      switch N
%         case 0
%             R=Iw;
%         case 1
%             G=Iw;
%         case 2
%             B=Iw;
%      end
           if N==0
                     R=Iw;
            elseif N== 1
                    G=Iw;
            elseif N== 2
                    B=Iw;
           end
   
    if nBit >= CR
            break;
    end
end
end

function  [ID]=SD_meoth(y,k)
MeaV=mean(y);
StrV=std(y);
MaxV=MeaV+k*StrV;
MinV=MeaV-k*StrV;
ID=find(y>MinV & y<MaxV);
end

function  [ID]=MAD_meoth(y,k)
MedV=median(y);
YMed1=abs(MedV*ones(length(y),1)-y);
Dit=YMed1./median(YMed1);
ID=find(Dit<k);
end
