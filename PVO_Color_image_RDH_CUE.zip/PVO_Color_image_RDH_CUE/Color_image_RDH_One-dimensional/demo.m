% a demo how to use the codec
% date: 07/01/2022
% author: Ningxiong Mao (502441062@qq.com)
clc
close all
clear all
imgdir = dir('*.tiff');
fid=fopen('fileName.txt','wt');
% performance = zeros(length(imgdir)*5,100);
% kperformance = zeros(10*5,100);
k=0;

I=double (imread([imgdir(1).name])); %Baboon.bmp
% total capcity(pure capacity without locationmap and auxiliary LSB bits)

[nperformance]=colorRDH(I,k);
% performance(5*(i-1)+1:5*(i),:) = nperformance;


% save('PVOperformance.mat','performance')
fclose(fid);

